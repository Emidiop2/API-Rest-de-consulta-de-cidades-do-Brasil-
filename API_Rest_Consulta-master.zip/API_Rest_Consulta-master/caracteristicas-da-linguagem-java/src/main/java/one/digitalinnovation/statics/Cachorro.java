package one.digitalinnovation.statics;

public class Cachorro {

    //public String zoologia = "Quadrupede"; //Uma instância
    public static String zoologia = "Quadrupede"; //Todas instâncias

    public static String late() {
        return "Au!Au!";
    }

}
