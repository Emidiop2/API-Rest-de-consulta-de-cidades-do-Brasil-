package one.digitalinnovation.classes.pessoa;

public class PessoaFisica extends Pessoa {

    public PessoaFisica(final Integer idade, final Float peso) {
        super(idade, peso);
    }
}
